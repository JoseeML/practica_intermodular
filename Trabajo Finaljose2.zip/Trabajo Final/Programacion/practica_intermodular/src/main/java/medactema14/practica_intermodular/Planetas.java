/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medactema14.practica_intermodular;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Planetas {
   String  nombre ;
   String tipo_estrella;
   float radio;
   float temperatura;
   float distancia_media;
   String  composicion;
   String fecha_creacion;
   float P_orbita;
   int n_satelites;
   ArrayList<Satelites>satelites=new ArrayList<>();

    public Planetas(String nombre, String tipo_estrella, float radio, float temperatura, float distancia_media, String composicion, String fecha_creacion, float P_orbita, int n_satelites) {
        this.nombre = nombre;
        this.tipo_estrella = tipo_estrella;
        this.radio = radio;
        this.temperatura = temperatura;
        this.distancia_media = distancia_media;
        this.composicion = composicion;
        this.fecha_creacion = fecha_creacion;
        this.P_orbita = P_orbita;
        this.n_satelites = n_satelites;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo_estrella() {
        return tipo_estrella;
    }

    public void setTipo_estrella(String tipo_estrella) {
        this.tipo_estrella = tipo_estrella;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public float getDistancia_media() {
        return distancia_media;
    }

    public void setDistancia_media(float distancia_media) {
        this.distancia_media = distancia_media;
    }

    public String getComposicion() {
        return composicion;
    }

    public void setComposicion(String composicion) {
        this.composicion = composicion;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public float getP_orbita() {
        return P_orbita;
    }

    public void setP_orbita(float P_orbita) {
        this.P_orbita = P_orbita;
    }

    public int getN_satelites() {
        return n_satelites;
    }

    public void setN_satelites(int n_satelites) {
        this.n_satelites = n_satelites;
    }

    public ArrayList<Satelites> getSatelites() {
        return satelites;
    }

    public void setSatelites(ArrayList<Satelites> satelites) {
        this.satelites = satelites;
    }
   
   
    
}
