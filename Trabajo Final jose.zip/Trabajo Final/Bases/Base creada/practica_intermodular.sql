drop  database practica_intermodular;
create database practica_intermodular; 
use practica_intermodular;


create table estrella(
	id_estrella INT PRIMARY KEY,
	nombre varchar(200) ,
	tipo varchar(200),
    radio float,
	temperatura float,
    distancia float,
    composicion varchar(1000),
    fecha_creacion date
  
);
create table Planeta(
	id_planeta INT PRIMARY KEY,
	nombre varchar(200) ,
    radio float,
    distancia float,
    periodo_orbitario float,
    temperatura float,
       tipo varchar(200),
       fecha_creacion date,
       num_satelites int NOT NULL default 0,
	id_estrella INT NOT NULL,
FOREIGN KEY (id_estrella) REFERENCES estrella(id_estrella)
);

create table Satelite(
id_satelite INT PRIMARY KEY,
	nombre varchar(200) ,	
    radio float,
    distancia float,
    periodo_orbitario float,
    temperatura float,
	tipo varchar(200),
    fecha_creacion date,
	id_planeta INT NOT NULL,
    FOREIGN KEY (id_planeta) REFERENCES planeta(id_planeta)
);
DELIMITER //
CREATE TRIGGER fecha_creacion_estrella
BEFORE INSERT ON estrella
FOR EACH ROW
BEGIN

  SET NEW.Fecha_Creacion = sysdate();
END;
//
CREATE TRIGGER fecha_creacion_planeta
BEFORE INSERT ON Planeta
FOR EACH ROW
BEGIN
  SET NEW.Fecha_Creacion = CURDATE();
END;
//
CREATE TRIGGER fecha_creacion_satelite
BEFORE INSERT ON Satelite
FOR EACH ROW
BEGIN
  SET NEW.Fecha_Creacion = CURDATE();
END;
//
-- Creación del trigger para actualizar el número de satélites en la tabla 
CREATE TRIGGER actualiza_num_satelites
AFTER INSERT ON Satelite
FOR EACH ROW
BEGIN
  UPDATE Planeta SET num_satelites = (SELECT COUNT(*) FROM Satelite WHERE id_planeta = NEW.id_planeta)
  WHERE id_planeta = NEW.id_planeta;
END;
//
DELIMITER ;

INSERT INTO estrella (id_estrella, nombre, tipo, radio, temperatura, distancia , composicion)
VALUES
 (1,'Sol', 'G2V', 696340, 5500, 149.6, '74% Hidrógeno, 24% Helio, 2% Otros');

INSERT INTO Planeta (id_planeta, nombre,radio, distancia,periodo_orbitario , temperatura ,tipo, id_estrella)
VALUES
(1, 'Mercurio', 2439.7, 57.9, 88.0, 167.0,'Rocoso', 1),
(2, 'Venus', 6051.8, 108.2, 225, 464, 'Rocoso', 1),
(3, 'Tierra', 6371.0, 149.6, 365.25, 15, 'Rocoso', 1),
(4, 'Marte', 3389.5, 227.9, 687, -65, 'Rocoso', 1),
(5, 'Júpiter',  69911.0, 778.5, 4333, -110, 'Gaseoso', 1),
(6, 'Saturno', 58232.0, 1429.4, 10759, -140, 'Gaseoso', 1),
(7, 'Urano', 25362.0, 2870.9, 30687, -195, 'Gaseoso', 1),
(8, 'Neptuno', 24622.0, 4498.3, 60190, -200, 'Gaseoso', 1);

INSERT IGNORE INTO Satelite (id_satelite, nombre,radio, distancia,periodo_orbitario , temperatura , tipo, id_planeta)
VALUES
(1, 'Luna', 1737.4, 384400, 27.3, -53, 'Sólido/Rocoso',3),
(2, 'Fobos', 11.1, 9378, 0.3, -40, 'Sólido/Rocoso', 4),
(3, 'Deimos', 6.2, 23460, 1.3, -40, 'Sólido/Rocoso', 4),
(4, 'Ío', 1821.6, 421700, 1.8, -143, 'Sólido/Rocoso', 5),
(5, 'Europa',1560.8, 670900, 3.5, -160, 'Sólido/Hielo', 5),
(6, 'Ganimedes',2634.1, 1070400, 7.2, -163, 'Sólido/Hielo', 5),
(7, 'Calisto', 2410.3, 1882700, 16.7, -139, 'Sólido/Hielo', 5),
(8, 'Titán', 2575.5, 1222000, 15.9, -179, 'Sólido/Hielo', 6),
(9, 'Encélado', 252.1, 238000, 1.4, -201, 'Sólido/Hielo', 6),
(10, 'Titania', 788.4, 435900, 8.7, -203, 'Sólido/Hielo', 7),
(11, 'Oberón', 761.4, 583500, 13.5, -203, 'Sólido/Hielo', 7);

select * from Planeta;












